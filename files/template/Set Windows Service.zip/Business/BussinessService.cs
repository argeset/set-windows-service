﻿using System;
using $safeprojectname$.Business.Contract;

namespace $safeprojectname$.Business
{
    public class BussinessService : BaseService, IBussinessService
    {
        public void DoWork()
        {
            Console.WriteLine("I do something");
        }
    }
}
