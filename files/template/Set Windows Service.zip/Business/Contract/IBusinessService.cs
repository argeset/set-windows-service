﻿using System.ServiceModel;

namespace $safeprojectname$.Business.Contract
{
    [ServiceContract]
    public interface IBusinessService
    {
        [OperationContract]
        void DoWork();
    }
}