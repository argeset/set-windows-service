﻿namespace $safeprojectname$.Business
{
    public class BaseService
    {
    }
}