﻿using System.ServiceModel;

namespace $safeprojectname$.Business.Contract
{
    [ServiceContract]
    public interface IBussinessService
    {
        [OperationContract]
        void DoWork();
    }
}